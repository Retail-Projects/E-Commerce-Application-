package com.grocery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GreenBasketApplication {

	public static void main(String[] args) {
		SpringApplication.run(GreenBasketApplication.class, args);
	}

}
