package com.grocery.entity;

import lombok.Data;

@Data
public class MailEntity {
    private String subject;
    private String message;
}
