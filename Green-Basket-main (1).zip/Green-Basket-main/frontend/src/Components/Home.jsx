import React from "react";
import Corosel from "./Corosel";
import Category from "./Category";
const Home=()=>{
    return(<>
    <Corosel/>
    <Category/>
    </>)
}
export default Home;